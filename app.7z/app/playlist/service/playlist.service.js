/**
 * Created by vtkhoi on 2/24/2017.
 */

angular.module('songApp')
  .factory('PlayListFactory', function () {

    /* set get */
    var lstPlayList = [
      {
        id: '1',
        name: 'PlayList 2011',
        description: 'Imagine Dragon'
      },
      {
        id: '2',
        name: 'PlayList 2012',
        description: 'Imagine Dragon'
      },
      {
        id: '3',
        name: 'PlayList 2013',
        description: 'Imagine Dragon'
      },
      {
        id: '4',
        name: 'PlayList 2014',
        description: 'Imagine Dragon'
      },
      {
        id: '5',
        name: 'PlayList 2015',
        description: 'Imagine Dragon'
      },
      {
        id: '6',
        name: 'PlayList 2016',
        description: 'Imagine Dragon'
      },
      {
        id: '7',
        name: 'PlayList 2017',
        description: 'Imagine Dragon'
      },
      {
        id: '8',
        name: 'PlayList 2018',
        description: 'Imagine Dragon'
      },
      {
        id: '9',
        name: 'PlayList 2019',
        description: 'Imagine Dragon'
      }
    ];

    function getListPlayList() {
      return lstPlayList;
    }

    // lstSongOfPlayList
    var lstSongOfPlayList = [
      {
        idplaylist: '1',
        idSong: '1'
      },
      {
        idplaylist: '1',
        idSong: '2'
      },
      {
        idplaylist: '2',
        idSong: '3'
      },
      {
        idplaylist: '2',
        idSong: '4'
      }
    ];

    function getListSongOfPlayList() {
      return lstSongOfPlayList;
    }

    //used for function edit playlist and checkbox of addSong Tab.
    function getListSongOfPlaylistByID(playlistId) {

      console.log("getListSongOfPlaylistByID");
      var listSong = [];
      for (var index = 0; index < lstSongOfPlayList.length; index++) {
        var songOfPlaylist = lstSongOfPlayList[index];
        if (songOfPlaylist.idplaylist === playlistId) {
          listSong.push(songOfPlaylist.idSong);
        }
      }
      console.log("listSong.length " + listSong.length);
      return listSong;
    }

    // end lstSongOfPlayList

    /* operation */

    /*** add ***/
    function addPlayList(newName, newDesc) {

      var uid = lstPlayList.length + 1;

      lstPlayList.push({
        id: uid,
        name: newName,
        description: newDesc
      });

    };

    // tab addSong
    function updateSongForPlaylist(lstNewSongIdOfPlaylist) {

      console.log("updateSongForPlaylist");
      //remove Old list
      var lstOldSongOfPlaylist = getListSongOfPlaylistByID(selectedPlayList.id);

      //remove all playlist have id selectedPlayList.id
      for (var index = 0; index < lstSongOfPlayList.length; index++) {
        var oldSong = lstSongOfPlayList[index];
        if (oldSong.idplaylist === selectedPlayList.id) {
          lstSongOfPlayList.splice(index, 1);
          console.log("lstSongOfPlayList.pop " + oldSong.idplaylist + " index " + index + " selectedPlayList.id " + selectedPlayList.id);
        }
      }

      //add newSong
      for (var index = 0; index < lstNewSongIdOfPlaylist.length; index++) {
        var newSongId = lstNewSongIdOfPlaylist[index];
        console.log("newSongId push " + newSongId);
        lstSongOfPlayList.push({
          idplaylist: selectedPlayList.id,
          idSong: newSongId
        });
      }
    }


    // if view playlist clicked edit button. save.
    var selectedPlayList = {};

    function setSelectedPlayList(playList) {

      selectedPlayList.id = playList.id;
      selectedPlayList.name = playList.name;
      selectedPlayList.description = playList.description;

    }

    function getSelectedPlayList() {
      return selectedPlayList;
    }

    /*********** edit **************/
    function editPlayList(songTitle, songArtist) {

      for (var index = 0; index < lstPlayList.length; ++index) {

        var playlist = lstPlayList[index];
        if (playlist.id === selectedPlayList.id) {
          playlist.name = songTitle;
          playlist.description = songArtist;
          return;
        }
      }
    }

    /*********** delete **************/
    function deletePlayListOf(lstSongId) {

      for (var index = 0; index < lstSongId.length; index++) {
        for (var indexSong = 0; indexSong < lstPlayList.length; indexSong++) {
          if (lstSongId[index] === lstPlayList[indexSong].id) {
            deletePlayListByIndex(indexSong);
          }
        }
      }
    }

    function deletePlayListByIndex(index) {
      lstPlayList.splice(index, 1);
    };

    function deletePlayLists() {
      lstPlayList.length = 0;
    }

    function doApplyAddSong(lstAddSong) {


    }

    return {
      getListPlayList: getListPlayList,
      addPlayList: addPlayList,
      setSelectedPlayList: setSelectedPlayList,
      getSelectedPlayList: getSelectedPlayList,
      editPlayList: editPlayList,
      deletePlayListByIndex: deletePlayListByIndex,
      deletePlayLists: deletePlayLists,
      deletePlayListOf: deletePlayListOf,
      getListSongOfPlaylistByID: getListSongOfPlaylistByID,
      updateSongForPlaylist: updateSongForPlaylist
    }

  });

