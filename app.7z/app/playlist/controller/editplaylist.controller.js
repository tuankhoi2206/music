/**
 * Created by vtkhoi on 2/16/2017.
 */
'use strict';

/**
 * @ngdoc function
 * @name songApp.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the songApp
 */
angular.module('songApp')
  .controller('EditPlaylistCtrl', function ($location, PlayListFactory, SongFactory) {

    var vm = this;
    // vm.titleName = 'Edit Playlist';
    vm.searchText = '';// set the default search/filter
    vm.songs = angular.copy(SongFactory.getSongs());// get the list song
    vm.sortType = 'name'; // set the default sort type
    vm.sortReverse = false;  // set the default sort order
    vm.titles = ["Home", "Playlists"];
    vm.isDisabledButton = true;// disable revert and apply button
    vm.isDisabledApplyBtn = true;// disable revert and apply button

    vm.changeRoute = function (path) {
      $location.path("/".concat(path));
    }

    vm.showInfoTab = true;
    vm.showTab = 1;
    vm.displayTab = function (tagName) {
      if ('infor' === tagName && vm.showTab === 0) {
        vm.showTab++;
      }
      else if ('addsong' === tagName && vm.showTab === 1) {
        vm.showTab--;
      }
    };


    // get playList clicked playlist view.
    var playlist = PlayListFactory.getSelectedPlayList();
    vm.playlistName = playlist.name;
    vm.playlistDescription = playlist.description;
    vm.updatePlaylist = function () {
      PlayListFactory.editPlayList(vm.playlistName, vm.playlistDescription);
      vm.changeRoute('playlist');
    };

    vm.changeText = function () {
      if (vm.playlistName != playlist.name || vm.playlistDescription != playlist.description) {
        vm.isDisabledApplyBtn = false;
      } else {
        vm.isDisabledApplyBtn = true;
      }
    };

    // checkbox in header table
    vm.isCheckedMasterChkBox = false;
    vm.stageChangeMasterChkBox = function () {
      for (var i = 0; i < vm.songs.length; i++) {
        vm.songs[i].songChecked = vm.isCheckedMasterChkBox;
        console.log(vm.songs[i].songChecked);
      }
    };

    //load listsong of playlist used for addSong tab.
    vm.songsOfPlaylist = PlayListFactory.getListSongOfPlaylistByID(playlist.id);
    vm.songsOfOriginalPlayList = PlayListFactory.getListSongOfPlaylistByID(playlist.id);//listSong without modification
    vm.isExistInListSongOfPlaylist = function () {
      for (var index = 0; index < vm.songsOfPlaylist.length; index++) {
        var songOfPlaylist = vm.songsOfPlaylist[index];
        for (var j = 0; j < vm.songs.length; j++) {
          var song = vm.songs[j];
          if (song.id === songOfPlaylist) {
            song.songChecked = true;
          }
        }
      }
    };
    vm.isExistInListSongOfPlaylist();

    vm.stageChangeChkBox = function stageChangeChkBox(songId) {

      vm.songsOfPlaylist.indexOf(songId) > -1 ? vm.songsOfPlaylist.splice(vm.songsOfPlaylist.indexOf(songId), 1) : vm.songsOfPlaylist.push(songId);
      // listSongOfPlayList is change element
      angular.equals(vm.songsOfOriginalPlayList, vm.songsOfPlaylist) ? vm.isDisabledButton = true : vm.isDisabledButton = false;
      //is select all checkbox
      vm.songs.length === vm.songsOfPlaylist.length ? vm.isCheckedMasterChkBox = true : vm.isCheckedMasterChkBox = false;

    };

    vm.revertListSong = function revertListSong() {
      vm.songsOfPlaylist = PlayListFactory.getListSongOfPlaylistByID(playlist.id);
      vm.songs = angular.copy(SongFactory.getSongs());
      vm.isExistInListSongOfPlaylist();
      vm.isCheckedMasterChkBox = false;
      vm.isDisabledButton = true;
    };


    //do change add song for playlist
    vm.doApplyAddSong = function doApplyAddSong() {
      PlayListFactory.updateSongForPlaylist(vm.songsOfPlaylist);
      vm.changeRoute('playlist');
    };
  })
;


