(function () {
  'use strict';
  angular.module('songApp')
    .controller('PlaylistCtrl', ['$location', 'PlayListFactory',
      function ($location, PlayListFactory) {

        var vm = this;
        vm.searchFish = '';// set the default search/filter
        vm.lstPlayList = PlayListFactory.getListPlayList();// get the list song
        vm.sortType = 'name'; // set the default sort type
        vm.sortReverse = false;  // set the default sort order
        vm.isDisabledBtn = true;
        vm.listCheckedChkBox = [];
        vm.isCheckedHeaderChkbox = false;

        vm.titleName = 'PlayLists';
        vm.titles = ['Home', 'Playlists'];
        vm.titleColumns = ['ID', 'Name', 'Description', 'Action'];

        vm.changeRoute = function (path) {
          $location.path('/'.concat(path));
        };

        vm.directToEditPage = function (playlist) {
          $location.path('editeplaylist');
          /** put selected song to service */
          PlayListFactory.setSelectedPlayList(playlist);
        };

        /******* delete ********/
        vm.removeByIndex = function (index) {
          PlayListFactory.deletePlayListByIndex(index);
        };

        vm.deletePlayLists = function deletePlayLists() {
          if (vm.isCheckedMasterChkBox) {
            PlayListFactory.deletePlayLists();
            vm.isCheckedHeaderChkbox = false;
            vm.isDisabledBtn = true;
          }
          else {
            if (vm.listCheckedChkBox.length === vm.lstPlayList.length) {
              vm.isCheckedHeaderChkbox = false;
            }
            PlayListFactory.deletePlayListOf(vm.listCheckedChkBox);
            vm.listCheckedChkBox.length = 0;
            vm.isDisabledBtn = true;
          }
        };

        vm.formatData = function (data) {
          return {
            col1: data.id,
            col2: data.name,
            col3: data.description
          }
        };
      }])
  ;
})();
