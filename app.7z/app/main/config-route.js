'use strict';

/**
 * @ngdoc overview
 * @name songApp
 * @description
 * # songApp
 *
 * Main module of the application.
 */
angular
  .module('songApp', [
    // 'ngAnimate',
    // 'ngCookies',
    // 'ngResource',
    'ngRoute'
    // 'ngSanitize',
    // 'ngTouch'
  ])
  .config(function ($routeProvider) {
    $routeProvider
      .when('/', {
        templateUrl: 'song/views/songs.html',
        controller: 'SongCtrl',
        controllerAs: 'vm'
      })//song
      .when('/songs', {
        templateUrl: 'song/views/songs.html',
        controller: 'SongCtrl',
        controllerAs: 'vm'
      })
      .when('/createsong', {
        templateUrl: 'song/views/createsong.html',
        controller: 'CreateSongCtrl',
        controllerAs: 'vm'
      })
      .when('/editsong', {
        templateUrl: 'song/views/editsong.html',
        controller: 'EditSongCtrl',
        controllerAs: 'vm'
      })// end song
      .when('/playlist', {
        templateUrl: 'playlist/views/playlists.html',
        controller: 'PlaylistCtrl',
        controllerAs: 'vm'
      })
      .when('/createplaylist', {
        templateUrl: 'views/playlistPage/createplaylist.html',
        controller: 'CreatePlaylistCtrl',
        controllerAs: 'vm'
      })
      .when('/editeplaylist', {
        templateUrl: 'views/playlistPage/editplaylist.html',
        controller: 'EditPlaylistCtrl',
        controllerAs: 'vm'
      })
      .otherwise({
        redirectTo: '/'
      });
  });
