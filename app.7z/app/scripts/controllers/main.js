'use strict';

/**
 * @ngdoc function
 * @name fountainInjectApp.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the fountainInjectApp
 */
angular.module('fountainInjectApp')
  .controller('MainCtrl', function () {
    var vm = this;

    vm.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
    vm.test = 'ABC';
  });
