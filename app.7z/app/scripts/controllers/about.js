'use strict';

/**
 * @ngdoc function
 * @name fountainInjectApp.controller:AboutCtrl
 * @description
 * # AboutCtrl
 * Controller of the fountainInjectApp
 */
angular.module('fountainInjectApp')
  .controller('AboutCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
