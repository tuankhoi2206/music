/**
 * Created by vtkhoi on 2/16/2017.
 */
'use strict';

/**
 * @ngdoc function
 * @name fountainInjectApp.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the fountainInjectApp
 */
angular.module('fountainInjectApp')
  .controller('PlaylistCtrl', function ($location,$scope) {
    var vm = this;

    vm.changeRoute = function(path){
      $location.path($location.path() + path);
    }

    $scope.titleName = 'Playlists';

    console.log($scope.titleName);
  })
;

