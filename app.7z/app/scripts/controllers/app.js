'use strict';

/**
 * @ngdoc function
 * @name fountainInjectApp.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the fountainInjectApp
 */
angular.module('fountainInjectApp')
  .controller('AppCtrl', function ($location) {
    var vm = this;

    vm.changeRoute = function(path){
      $location.path($location.path() + path);
    }
  })
;
