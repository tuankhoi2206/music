'use strict';

/**
 * @ngdoc overview
 * @name fountainInjectApp
 * @description
 * # fountainInjectApp
 *
 * Main module of the application.
 */
angular
  .module('fountainInjectApp', [
    // 'ngAnimate',
    // 'ngCookies',
    // 'ngResource',
    'ngRoute'
    // 'ngSanitize',
    // 'ngTouch'
  ])
  .config(function ($routeProvider) {
    $routeProvider
      .when('/', {
        templateUrl: 'views/songs.html',
        controller: 'SongCtrl',
        controllerAs: 'songs'
      })
      .when('/about', {
        templateUrl: 'views/about.html',
        controller: 'AboutCtrl',
        controllerAs: 'about'
      })
      .when('/songs', {
        templateUrl: 'views/songs.html',
        controller: 'SongCtrl',
        controllerAs: 'songs'
      })
      .when('/playlist', {
        templateUrl: 'views/playlists.html',
        controller: 'PlaylistCtrl',
        controllerAs: 'playlist'
      })
      .otherwise({
        redirectTo: '/'
      });
  });
