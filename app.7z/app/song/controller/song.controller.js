(function () {
  'use strict';
  angular.module('songApp')
    .controller('SongCtrl', ['$location', 'SongFactory',
      function ($location, SongFactory) {
        var vm = this;

        vm.searchText = '';// set the default search/filter
        vm.songs = SongFactory.getSongs();// get the list song
        vm.sortType = 'name'; // set the default sort type
        vm.sortReverse = false;  // set the default sort order
        vm.listCheckedChkBox = [];//list checkbox is check
        vm.isCheckedHeaderChkbox = false;
        vm.isDisabledBtn = true;

        vm.titleName = 'Songs';
        vm.titles = ['Home', 'Song']; //set title for breadcrumbs nav
        vm.titleColumns = ['ID', 'Name', 'Artist', 'Action'];

        /*** directional url ***/
        vm.changeRoute = function (path) {
          $location.path('/'.concat(path));
        };

        vm.directToEditPage = function (song) {
          $location.path('editsong');
          /** put selected song to service */
          SongFactory.setSelectedSong(song);
        };

        /*** remove ***/
        vm.removeByIndex = function (index) {
          SongFactory.removeSong(index);
        };

        /*** checkbox in header table ***/
        vm.removeSongs = function removeSongs() {
          if (vm.isCheckedHeaderChkbox) {
            SongFactory.removeSongs();
            vm.isCheckedHeaderChkbox = false;
            vm.isDisabledBtn = true;
          }
          else {
            if (vm.listCheckedChkBox.length === vm.songs.length) {
              vm.isCheckedHeaderChkbox = false;
            }
            SongFactory.removeSongById(vm.listCheckedChkBox);
            vm.listCheckedChkBox.length = 0;
            vm.isDisabledBtn = true;
          }
        }

        /*format data used for List-view*/
        vm.formatData = function (data) {
          return {
            col1: data.id,
            col2: data.title,
            col3: data.artists
          }
        };

      }])
  ;
})();
