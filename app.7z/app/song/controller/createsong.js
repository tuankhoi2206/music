/**
 * Created by vtkhoi on 2/17/2017.
 */'use strict';

/**
 * @ngdoc function
 * @name songApp.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the songApp
 */
angular.module('songApp')
  .controller('CreateSongCtrl', function ($location, $scope, SongFactory) {
    var vm = this;
    vm.titles = ["Home", "Song"];
    vm.titleName = 'CreateSong';
    vm.hasError = false;
    vm.isDisabledCreate = true;
    /*** add ***/
    //model initial
    vm.newSongTitle = '';
    vm.newSongArtist = '';

    vm.add = addSong;
    vm.checkInput = checkInput;

    function addSong(titleNew, artistNew) {
      SongFactory.addSong(titleNew, artistNew);
      changeRoute('songs');
    }

    function changeRoute(path) {
      $location.path($location.path() + path);
    }

    function checkInput(songTitle) {
      // return (songTitle === "" || angular.isUndefined(songTitle)) ? vm.hasError=true :vm.hasError=false;
      if (songTitle === "" || angular.isUndefined(songTitle)) {
        vm.hasError = true;
        vm.isDisabledCreate = true;
      } else {
        vm.hasError = false;
        vm.isDisabledCreate = false;
      }
    }
  })
;

