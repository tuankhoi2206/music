/**
 * Created by vtkhoi on 2/16/2017.
 */
'use strict';

/**
 * @ngdoc function
 * @name songApp.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the songApp
 */
angular.module('songApp')
  .controller('EditSongCtrl', function ($location, SongFactory) {
    var vm = this;
    vm.titleName = 'EditSong';
    vm.titles = ["Home", "Song"];
    vm.isDisabledApplyBtn = true;
    var song = SongFactory.getSelectedSong();
    vm.songTitle = song.title;
    vm.songArtist = song.artists;

    vm.changeText = function () {
      if (vm.songTitle != song.title || vm.songArtist != song.artists) {
        vm.isDisabledApplyBtn = false;
      }
      else {
        vm.isDisabledApplyBtn = true;
      }
    }
  })
;


