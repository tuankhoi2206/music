/**
 * Created by vtkhoi on 2/21/2017.
 */
angular.module('songApp')
    .factory('SongFactory', function () {

        var songFactory = [
            {
                id: '1',
                title: 'Radioactive 1',
                artists: 'Imagine Dragon'
            },
            {
                id: '2',
                title: 'Shape of You',
                artists: 'Ed Sheeran'
            }
            ,
            {
                id: '3',
                title: 'Something Just Like This',
                artists: 'The Chainsmokers & Coldplay'
            }
            ,
            {
                id: '4',
                title: 'The Weeknd',
                artists: 'Starboy ft.Daft Punk'
            },
            {
                id: '5',
                title: 'Chained To The Rhythm',
                artists: 'Katy Perry'
            },
            {
                id: '6',
                title: 'Chained To The Rhythm',
                artists: 'Katy Perry'
            },
            {
                id: '7',
                title: 'Chained To The Rhythm',
                artists: 'Katy Perry'
            },
            {
                id: '8',
                title: 'Chained To The Rhythm',
                artists: 'Katy Perry'
            },
            {
                id: '9',
                title: 'Chained To The Rhythm',
                artists: 'Katy Perry'
            }
        ];

        function getSongs() {
            return songFactory;
        };

        function removeSong(index) {
            songFactory.splice(index, 1);
        };

        /*** add ***/
        function addSong(titleNew, artistNew) {

            var uid = songFactory.length + 1;
            songFactory.push({
                id: uid,
                title: titleNew,
                artists: artistNew
            });
        };

        function editSong(songTitle, songArtist) {
            for (var index = 0; index < songFactory.length; ++index) {
                var song = songFactory[index];
                if (song.id === selectedSong.id) {
                    console.log("edit title " + songTitle);
                    console.log("edit artist " + songArtist);
                    song.title = songTitle;
                    song.artists = songArtist;
                    return;
                }
            }
        }

        var selectedSong = {};

        function setSelectedSong(song) {
            selectedSong.id = song.id;
            selectedSong.title = song.title;
            selectedSong.artists = song.artists;
        }

        function getSelectedSong() {
            return selectedSong;
        }


        function removeSongById(lstSongId) {

            for (var index = 0; index < lstSongId.length; index++) {
                for (var indexSong = 0; indexSong < songFactory.length; indexSong++) {
                    if (lstSongId[index] === songFactory[indexSong].id) {
                        removeSong(indexSong);
                    }
                }
            }
        }

        function removeSongs(lstSongs) {

            for (var index = 0; index < lstSongs.length; index++) {
                for (var indexSong = 0; indexSong < songFactory.length; indexSong++) {
                    if (lstSongs[index].id === songFactory[indexSong].id) {
                        removeSong(indexSong);
                    }
                }
            }
        }

        function removeSongs() {
            songFactory.length = 0;
        }

        return {
            getSongs: getSongs,
            removeSong: removeSong,
            addSong: addSong,
            setSelectedSong: setSelectedSong,
            getSelectedSong: getSelectedSong,
            editSong: editSong,
            removeSongById: removeSongById,
            removeSongs: removeSongs
        }

    });

