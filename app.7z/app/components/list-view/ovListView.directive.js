/**
 * Created by vtkhoi on 3/3/2017.
 */
angular.module('songApp').directive('ovListView', function () {
  return {
    restrict: 'E',
    templateUrl: 'components/list-view/ovListViewDirective.html',
    scope: {
      idUl: '=', /*id of ul*/
      items: '=', /*convert data ???*/
      onDirectToEditPage: '=',
      onRemoveItemByIndex: '=',
      onRemove: '&',// used for message dialog
      formatData: '=',
      disableCheckedAll: '=',
      isCheckedHeaderChkbox: '=',
      listCheckedChkBox: '=', //
      searchText: '=?'
    },
    controller: 'ListViewCtrl',
    controllerAs: 'vm',
    bindToController: true
  };
});
