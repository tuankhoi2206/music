/**
 * Created by vtkhoi on 3/3/2017.
 */
(function () {
  'use strict';
  angular.module('songApp')
    .controller('TableViewCtrl', ['$scope',
      function ($scope) {
        var vm = this;
        vm.sortType = 'col1'; // set the default sort type
        vm.sortReverse = false;  // set the default sort order
        vm.elementFormat = {};
        vm.isCheckedHeaderChkbox = false;
        vm.disableCheckedAll = true; //set is enable allDelete Button

        vm.setElementFormat = function (data) {
          vm.elementFormat.col1 = data.col1;//id
          vm.elementFormat.col2 = data.col2;//title
          vm.elementFormat.col3 = data.col3;//artists
        };

        vm.listCheckedChkBox = [];// save list item checked.
        vm.stageChangeHeaderCheckbox = function () {
          for (var i = 0; i < vm.items.length; i++) {
            vm.items[i].isChecked = vm.isCheckedHeaderChkbox;
            vm.listCheckedChkBox.push(vm.items[i].id);
          }
          // enable AllDeleteBtn
          vm.disableCheckedAll = !vm.isCheckedHeaderChkbox;
        };

        vm.stageChangeChkBox = function stageChangeChkBox(songId) {
          /* exist songId*/
          if (vm.listCheckedChkBox.indexOf(songId) < 0) {
            vm.listCheckedChkBox.push(songId);
          }
          else {
            vm.listCheckedChkBox.splice(vm.listCheckedChkBox.indexOf(songId), 1);
          }
          /* display checkbox and AllDelete Button */
          if (vm.listCheckedChkBox.length == 0) {
            vm.disableCheckedAll = true;
          }
          else {
            vm.disableCheckedAll = false;
          }
          //is check all checkbox
          if (vm.listCheckedChkBox.length === vm.items.length) {
            vm.isCheckedHeaderChkbox = true;
          } else {
            vm.isCheckedHeaderChkbox = false;
          }
        };
        //used for Remove Button
        vm.indexSelectedItem = 0;
        vm.saveIndex = function (index) {
          vm.indexSelectedItem = index;
        };
      }])
  ;
})();
