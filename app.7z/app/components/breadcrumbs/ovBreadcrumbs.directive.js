/**
 * Created by vtkhoi on 2/22/2017.
 */

var breadcrumbs = function () {
  return {
    restrict: 'E',
    templateUrl: 'components/breadcrumbs/ovBreadcrumbsDirective.html',
    scope: {
      titles: '='
    },
    controller: 'BreadCrumbsCtrl',
    controllerAs: 'vm',
    bindToController: true
  };
};
angular.module('songApp').directive('ovBreadcrumbs', breadcrumbs);
