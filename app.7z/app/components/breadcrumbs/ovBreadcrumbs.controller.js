/**
 * Created by vtkhoi on 3/10/2017.
 */
(function () {
  'use strict';
  angular.module('songApp')
    .controller('BreadCrumbsCtrl', ['$scope',
      function ($scope) {
        var vm = this;
      }])
})();
