'use strict';

angular
  .module('songApp', [
    // 'ngAnimate',
    // 'ngCookies',
    // 'ngResource',
    'ngRoute',
    'ngSanitize',
    'jm.i18next'
    // 'ngTouch'
  ]);
