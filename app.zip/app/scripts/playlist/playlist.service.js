(function () {
  'use strict';
  angular.module('songApp')
    .factory('PlayListFactory', ['$http', 'commonConstant', function ($http, commonConstant) {

      var views = {
        table: {
          title: 'Playlists',
          name: commonConstant.VIEW_MODE.SHOW,
          templateUrl: 'scripts/playlist/playlistTemplate.html'
        },
        add: {
          title: 'Create Playlist',
          name: commonConstant.VIEW_MODE.ADD,
          templateUrl: 'scripts/playlist/addPlaylist.html'
        },
        edit: {
          title: 'Edit Playlist',
          name: commonConstant.VIEW_MODE.EDIT,
          templateUrl: 'scripts/playlist/editPlaylist.html'
        }
      };

      var cache = {
        common: {
          playlistModel: {id: '', name: '', description: '', songs: []},
          isDisabledCreateOrApplyBtn: {status: true},// button model of create, apply button in create. edit playlist
        },
        currentView: views.table,
        editPlaylistView: {
          currentPlaylist: {id: '', name: '', description: '', songs: []},
          currentTab: commonConstant.SHOW_TAB.INFORMATION,
          addSongTab: {isDisabledApplyRevertBtn: {status: true}},// addsong Tab
        },
        showPlaylistView: {
          listCheckedChkBox: []
        }
      };

      return {
        views: views,
        cache: cache
      };
    }]);
})();
