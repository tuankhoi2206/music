(function () {
  'use strict';
  angular.module('songApp')
    .controller('PlaylistCtrl', ['$location', 'PlayListFactory', 'SongFactory', 'CommonService', 'commonConstant',
      function ($location, PlayListFactory, SongFactory, CommonService, commonConstant) {

        var vm = this;
        vm.cache = PlayListFactory.cache;

        function init() {
          //common mode
          vm.common = {
            configBreadcrumb: {titles: ['app.common.home', 'app.common.playlist']},
            isInputError: false,
            loadingState: true,
            function: {
              checkValueInput: checkValueInput,
              doCancel: doCancel
            }
          }

          /**** PLAYLIST TABLE ****/
          vm.showPlaylistView = {
            playlists: [],
            searchText: {text: ''},// set the default search/filter
            isCheckedHeaderChkbox: {status: false},
            isDisabledDeleteBtn: {status: true},
            function: {
              isShowMode: isShowMode,
              switchShowMode: switchShowMode,
              formatData: formatData,
              removeByIndex: removeByIndex,
              deletePlayLists: deletePlayLists,
              stageChangeChkBox: stageChangeChkBox // event click for every table row
            }
          }

          /**** ADD PLAYLIST ****/
          vm.addPlaylistView = {
            playlistModel: {id: '', name: '', description: ''},
            function: {
              isAddMode: isAddMode,
              addPlaylist: addPlaylist,
              switchAddMode: switchAddMode
            }
          }

          /**** EDIT PLAYLIST ****/
          vm.editPlaylistView = {
            showInfoTab: true,
            inforTab: {
              playlistModel: {id: '', name: '', description: ''}
            },
            addSongTab: {
              songs: [],
              // checkbox in header table
              isCheckedHeaderChkbox: false,
              songsOfPlaylist: [],
              listCheckedChkBoxSong: [],//song table used for addSong Tab},
            },
            function: {
              isInforTab: isInforTab,
              isSongTab: isSongTab,
              isEditMode: isEditMode,
              displayTab: displayTab,
              updatePlaylist: updatePlaylist,
              switchEditMode: switchEditMode,
              revertListSong: revertListSong,
              stageChangeHeaderChkBox: stageChangeHeaderChkBox,
              addSongOfPlaylist: addSongOfPlaylist
            }
          }
          initValuesCurrentView();
          /*************** EDIT PLAYLIST *****************/
          //config paramater
          vm.configDataPlaylistTable = {
            items: [],
            titleColumns: ['ID', 'Name', 'Description', 'Action'],
            isCheckedHeaderChkbox: vm.showPlaylistView.isCheckedHeaderChkbox,
            disableCheckedAll: vm.showPlaylistView.isDisabledDeleteBtn,
            listCheckedChkBox: vm.cache.showPlaylistView.listCheckedChkBox,
            searchText: vm.showPlaylistView.searchText
          };

          vm.configFuncPlaylistTable = {
            formatData: formatData,
            onDirectToEditPage: switchEditMode,
            onRemoveItemByIndex: removeByIndex
          };
          // end config
        }

        init();
        /** set value for current view **/
        function initValuesCurrentView() {

          if (vm.cache.currentView.name === commonConstant.VIEW_MODE.SHOW) {
            loadPlaylist();
          } else if (vm.cache.currentView.name === commonConstant.VIEW_MODE.EDIT
            && vm.cache.editPlaylistView.currentTab === commonConstant.SHOW_TAB.ADDSONG) {
            loadSongs();
          }
        }

        function setCheckBoxsModelPlaylist() {
          var listCheckBoxPlaylist = vm.cache.showPlaylistView.listCheckedChkBox;
          if (listCheckBoxPlaylist.length > 0) {
            for (var index = vm.showPlaylistView.playlists.length; index--;) {
              var playlist = vm.showPlaylistView.playlists[index];
              if (listCheckBoxPlaylist.indexOf(playlist.id) > -1) {
                playlist.isChecked = true;
              }
            }// end for
            if (listCheckBoxPlaylist.length === vm.showPlaylistView.playlists.length) {
              vm.showPlaylistView.isCheckedHeaderChkbox.status = true;
            }
            vm.showPlaylistView.isDisabledDeleteBtn.status = false;
          }
        }

        function switchShowMode() {
          vm.cache.currentView = PlayListFactory.views.table;
          vm.currentModePlayList = commonConstant.VIEW_MODE.SHOW;
          vm.showTab = commonConstant.SHOW_TAB.INFORMATION;
          loadPlaylist();
        }

        function isAddMode() {
          return vm.cache.currentView.name === commonConstant.VIEW_MODE.ADD;
        }

        function isShowMode() {
          return vm.cache.currentView.name === commonConstant.VIEW_MODE.SHOW;
        }

        function isEditMode() {
          return vm.cache.currentView.name === commonConstant.VIEW_MODE.EDIT;
        }

        function formatData(data) {
          return {
            col1: data.id,
            col2: data.name,
            col3: data.description
          };
        }

        function loadPlaylist() {
          CommonService.getData('api/playlist').then(function (reponse) {
            vm.showPlaylistView.playlists = reponse.data;
            vm.configDataPlaylistTable.items = reponse.data;
            if (isShowMode()) {
              setCheckBoxsModelPlaylist();
            }
          }, function (error) {
            console.log('error ', error)
          }).finally(
            function () {
              vm.loadingState = false;
            }
          );
        }

        /*************** ADD PLAYLIST *****************/

        function checkValueInput() {

          if (vm.cache.common.playlistModel.name === ""
            || angular.isUndefined(vm.cache.common.playlistModel.name)) {
            vm.common.isInputError = true;
            vm.cache.common.isDisabledCreateOrApplyBtn.status = true;
          } else {
            vm.common.isInputError = false;
            vm.cache.common.isDisabledCreateOrApplyBtn.status = false;
          }

          if (vm.cache.currentView.name === commonConstant.VIEW_MODE.EDIT) {
            if ((vm.cache.common.playlistModel.name != vm.cache.currentPlaylist.name && vm.cache.common.playlistModel.name.length > 0)
              || vm.cache.common.playlistModel.description != vm.cache.currentPlaylist.description) {
              vm.cache.common.isDisabledCreateOrApplyBtn.status = false;
            } else {
              vm.cache.common.isDisabledCreateOrApplyBtn.status = true;
            }
          }
        }

        function switchAddMode() {
          vm.currentModePlayList = commonConstant.VIEW_MODE.ADD;
          vm.cache.currentView = PlayListFactory.views.add;
          loadPlaylist();
        }

        function clearCachePlaylistModel() {
          vm.cache.common.playlistModel = {id: '', name: '', description: '', songs: []};
        }

        function clearCacheCurrentPlaylist() {
          vm.cache.editPlaylistView.currentPlaylist = {id: '', name: '', description: '', songs: []};
        }

        function resetIsDisabledCreateOrApplyBtn() {
          vm.cache.common.isDisabledCreateOrApplyBtn.status = true;
        }

        function addPlaylist() {
          CommonService.postData('api/playlist', angular.copy(vm.cache.common.playlistModel)).then(function (data) {
            clearCachePlaylistModel();
            resetIsDisabledCreateOrApplyBtn();
            switchShowMode();
          }, function (error) {
            console.log('error ', error)
          }).finally(
            function () {
              vm.common.loadingState = false;
            }
          );
        }

        /*************** EDIT PLAYLIST *****************/
        function isInforTab() {
          return vm.cache.editPlaylistView.currentTab === commonConstant.SHOW_TAB.INFORMATION;
        }

        function isSongTab() {
          return vm.cache.editPlaylistView.currentTab === commonConstant.SHOW_TAB.ADDSONG;
        }

        function displayTab(tagName) {
          if ('infor' === tagName) {
            vm.cache.editPlaylistView.currentTab = commonConstant.SHOW_TAB.INFORMATION;
          }
          else if ('addsong' === tagName) {
            vm.cache.editPlaylistView.currentTab = commonConstant.SHOW_TAB.ADDSONG;
            loadSongs();
          }
        }

        /*
         * cancel button of Create Playlist, Information Tab, AddSong Tab
         * Reset Page
         */
        function doCancel() {
          //cache tab
          if (vm.cache.editPlaylistView.currentTab === commonConstant.SHOW_TAB.ADDSONG) {
            vm.cache.editPlaylistView.currentTab = commonConstant.SHOW_TAB.INFORMATION;
            resetCheckBoxSongs();
          } else if (vm.cache.editPlaylistView.currentTab === commonConstant.SHOW_TAB.ADD) {
            resetIsDisabledCreateOrApplyBtn();
          }
          vm.common.isInputError = false;
          clearCacheCurrentPlaylist();
          clearCachePlaylistModel();
          switchShowMode();
        }

        function resetCheckBoxSongs() {
          var songs = vm.editPlaylistView.addSongTab.songs;
          for (var i = songs.length; i--;) {
            songs[i].songChecked = false;
          }
        }

        /*** SWITCH EDIT PAGE ***/
        function switchEditMode(selectedPlaylist) {

          vm.cache.common.playlistModel = selectedPlaylist;
          vm.cache.currentPlaylist = angular.copy(selectedPlaylist);

          vm.cache.currentView = PlayListFactory.views.edit;
          vm.showTab = commonConstant.SHOW_TAB.INFORMATION;

        }

        function updatePlaylist() {
          CommonService.putData('api/playlist', vm.cache.common.playlistModel).then(function (data) {
            clearCachePlaylistModel();
            clearCacheCurrentPlaylist();
            resetIsDisabledCreateOrApplyBtn();
            switchShowMode();
          }, function (error) {
            console.log('error ', error);
          }).finally(
            function () {
              vm.common.loadingState = false;
            }
          );
        }

        /************** TAB SONG *********************/

        // event change model for checkbox all
        function stageChangeHeaderChkBox() {
          var songs = vm.editPlaylistView.addSongTab.songs;
          if (songs.length > 0) {
            vm.cache.editPlaylistView.addSongTab.isDisabledApplyRevertBtn.status = false;
            var listId = [];
            for (var i = songs.length; i--;) {
              songs[i].songChecked = vm.editPlaylistView.addSongTab.isCheckedHeaderChkbox;
              listId.push(songs[i].id);
            }
            vm.cache.currentPlaylist.songs.length = 0;//vm.isCheckedHeaderChkbox is false
            if (vm.editPlaylistView.addSongTab.isCheckedHeaderChkbox) {
              vm.cache.currentPlaylist.songs = listId;
            }
            setCheckBoxsModel();
          }
          else {
            vm.editPlaylistView.addSongTab.isCheckedHeaderChkbox = false;
          }
        }

        /*** Used for Tab Song ***/
        function loadSongs() {
          CommonService.getData('api/song').then(function (response) {

            vm.editPlaylistView.addSongTab.songs = response.data;
            vm.configDataPlaylistTable.items = response.data;
            setCheckBoxsModel();
          }, function (error) {
            console.log('error ', error);
          }).finally(
            function () {
              vm.common.loadingState = false;
            }
          );
        }

        function setCheckBoxsModel() {
          var editPlayListView = vm.editPlaylistView.addSongTab;
          var cacheSongs = vm.cache.currentPlaylist.songs;

          if (cacheSongs.length > 0) {
            for (var index = editPlayListView.songs.length; index--;) {
              var song = editPlayListView.songs[index];
              song.isChecked = cacheSongs.indexOf(song.id) > -1;
            }

            if (editPlayListView.songs.length === cacheSongs.length) {
              editPlayListView.isCheckedHeaderChkbox = true;
            }
            else {
              editPlayListView.isCheckedHeaderChkbox = false;
            }
          } else {
            for (var index = editPlayListView.songs.length; index--;) {
              var song = editPlayListView.songs[index];
              song.isChecked = false;
            }
          }
        }

        /*
         * LOAD DATA FOR TABLE
         */

        function stageChangeChkBox(songId) {
          //1. add or remove song id of selectedPlaylist
          var currentPlaylist = vm.cache.currentPlaylist;
          if (currentPlaylist.songs.indexOf(songId) > -1) {
            currentPlaylist.songs.splice(currentPlaylist.songs.indexOf(songId), 1);
          }
          else {
            currentPlaylist.songs.push(songId);
          }

          //2. case songs changed song equals currentPlaylist.songs
          //playlistModel.songs []
          //currentPlaylist.songs []
          if (angular.equals(vm.cache.common.playlistModel.songs, currentPlaylist.songs)) {
            vm.cache.editPlaylistView.addSongTab.isDisabledApplyRevertBtn.status = true;
          }
          else {
            vm.cache.editPlaylistView.addSongTab.isDisabledApplyRevertBtn.status = false;
          }

          //3. is select all checkbox
          if (vm.editPlaylistView.addSongTab.songs.length === vm.cache.currentPlaylist.songs.length) {
            vm.editPlaylistView.addSongTab.isCheckedHeaderChkbox = true;
          } else {
            vm.editPlaylistView.addSongTab.isCheckedHeaderChkbox = false;
          }
        }

        /*
         *  event of Revert button
         *  Reset currentPlaylist.songs
         */
        function revertListSong() {
          vm.isCheckedHeaderChkbox = false;
          resetIsDisabledCreateOrApplyBtn();
          resetCacheIsDisabledApplyRevertBtn();
          //reset value vm.cache.common.playlistModel.songs because when clicked will change songs value
          vm.cache.currentPlaylist.songs = angular.copy(vm.cache.common.playlistModel.songs);
          loadSongs();
        }

        function addSongOfPlaylist() {

          CommonService.putData('api/playlist', angular.copy(vm.cache.currentPlaylist)).then(function (data) {
            loadSongs();

            //aysn playlistModel and currentPlaylist after save
            vm.cache.common.playlistModel = angular.copy(vm.cache.currentPlaylist);
            if (vm.editPlaylistView.addSongTab.songs.length !== vm.cache.currentPlaylist.length) {
              vm.isCheckedHeaderChkbox = false;
            }
            resetCacheIsDisabledApplyRevertBtn();
            resetIsDisabledCreateOrApplyBtn();
            // vm.switchShowMode();
          }, function (error) {
            console.log('error ', error)
          }).finally(
            function () {
              vm.common.loadingState = false;
            }
          );
        }

        function resetCacheIsDisabledApplyRevertBtn() {
          vm.cache.editPlaylistView.addSongTab.isDisabledApplyRevertBtn.status = true;
        }

        /******* delete ********/
        function removeByIndex(index) {
          var playlist = {id: [vm.showPlaylistView.playlists[index].id]};
          CommonService.deleteData('api/playlist', playlist).then(function (response) {
            //reload songs
            loadPlaylist();
          }, function (error) {
            console.log('error ', error)
          }).finally(
            function () {
            }
          );
        }

        function deletePlayLists() {
          if (vm.showPlaylistView.isCheckedHeaderChkbox.status) {
            vm.showPlaylistView.playlists.length = 0;
            vm.showPlaylistView.isCheckedHeaderChkbox.status = false;
            vm.showPlaylistView.isDisabledDeleteBtn.status = true;
          }
          else {
            if (vm.cache.showPlaylistView.listCheckedChkBox.length === vm.showPlaylistView.playlists.length) {
              vm.showPlaylistView.isCheckedHeaderChkbox.status = false;
            }
            deletePlayListOf(vm.cache.showPlaylistView.listCheckedChkBox);
            vm.cache.showPlaylistView.listCheckedChkBox.length = 0;
            vm.showPlaylistView.isDisabledDeleteBtn.status = true;
          }
        }


        function deletePlayListOf(lstSongId) {
          for (var index = lstSongId.length; index--;) {
            for (var indexSong = vm.showPlaylistView.playlists.length; indexSong--;) {
              if (lstSongId[index] === vm.showPlaylistView.playlists[indexSong].id) {
                vm.showPlaylistView.playlists.splice(indexSong, 1);
              }
            }
          }
        }
      }])
  ;
})();
